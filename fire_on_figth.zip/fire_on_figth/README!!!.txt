Soo you downloaded the game GREAT! you still can donate us! just go to the hub! and select "donator"! well if you donate you
support us lol







VERSION:5.0.9 (main version)


So yea whats this game? you migth be wondering... Its a game about punching! Inspired by Friday Nigth Funkin... 
you dont know whats FnF?(Friday Nigth Funkin) its the most coolest rythm game of the entire world!! Go play it by yourself too!
this game gonna be finished? well your playing the fullgame so yeah its finished! but some bug fixes migth go on or some bonus
levels in-game (wich are not released because they are a DLC) now go enjoy this action game! (probably the coolest one rigth?
wait thats a joke...) if there is any bugs report in comments! and the events of the game are at the hub only! to move in the 
events(that are in the hub) press the arrow buttons in screen! and join a server that is not full!(in the events)
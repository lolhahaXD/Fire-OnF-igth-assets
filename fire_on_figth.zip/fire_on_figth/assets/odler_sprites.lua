idle:sprite1
idle2:move end of sprite1 2%
attack:when hes close to Mday
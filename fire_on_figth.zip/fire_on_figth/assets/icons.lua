when_bar_80%_show_bad_icons
when_bar_10%_show_monday_bad.png
monday_appear_on:all levels
odler_appear:level 1
whitedbrod_appear:level 2
porpla_appear:level 3
Darklox(boss)_appear:level 4
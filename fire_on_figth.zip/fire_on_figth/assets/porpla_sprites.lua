idle:sprite1
idle2:sprite2
attack: show sprite3 when close to Mday
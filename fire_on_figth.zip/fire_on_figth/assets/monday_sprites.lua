idle:sprite 1
idle2:move end of sprite 1 2%
attack:when screen clicked show sprite 2
id:Mday



